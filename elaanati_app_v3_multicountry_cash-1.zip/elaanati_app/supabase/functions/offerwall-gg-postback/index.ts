import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const cors = { 'content-type': 'text/plain; charset=utf-8' };
const encoder = new TextEncoder();

function toHex(bytes: Uint8Array): string {
  return [...bytes].map((b) => b.toString(16).padStart(2, '0')).join('');
}
function centsFromDecimal(raw: string): bigint {
  if (!/^-?\d+(\.\d{1,6})?$/.test(raw)) throw new Error('invalid amount');
  const negative = raw.startsWith('-');
  const value = negative ? raw.slice(1) : raw;
  const [whole, fraction = ''] = value.split('.');
  const padded = (fraction + '000000').slice(0, 6);
  const micros = BigInt(whole) * 1_000_000n + BigInt(padded);
  // Placement must be configured in USD. Round down to cents, never up.
  const cents = micros / 10_000n;
  return negative ? -cents : cents;
}
async function validSignature(user: string, tx: string, amount: string, supplied: string, secret: string): Promise<boolean> {
  const key = await crypto.subtle.importKey('raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const signature = new Uint8Array(await crypto.subtle.sign('HMAC', key, encoder.encode(`${user}:${tx}:${amount}`)));
  const expected = toHex(signature).toLowerCase();
  const actual = supplied.toLowerCase();
  if (expected.length !== actual.length) return false;
  let mismatch = 0;
  for (let i = 0; i < expected.length; i++) mismatch |= expected.charCodeAt(i) ^ actual.charCodeAt(i);
  return mismatch === 0;
}

Deno.serve(async (req) => {
  if (req.method !== 'GET') return new Response('method not allowed', { status: 405, headers: cors });
  const url = new URL(req.url);
  const user = url.searchParams.get('user') ?? '';
  const tx = url.searchParams.get('tx') ?? '';
  const amountRaw = url.searchParams.get('amount') ?? '';
  const sig = url.searchParams.get('sig') ?? '';
  const secret = Deno.env.get('OFFERWALL_GG_SECRET') ?? '';
  const supabaseUrl = Deno.env.get('SUPABASE_URL') ?? '';
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';
  if (!secret || !supabaseUrl || !serviceKey) return new Response('server not configured', { status: 503, headers: cors });
  if (!user || !tx || !amountRaw || !sig || !/^[0-9a-f-]{36}$/i.test(user)) return new Response('bad request', { status: 400, headers: cors });
  if (!await validSignature(user, tx, amountRaw, sig, secret)) return new Response('bad signature', { status: 403, headers: cors });

  let cents: bigint;
  try { cents = centsFromDecimal(amountRaw); } catch { return new Response('bad amount', { status: 400, headers: cors }); }
  if (cents === 0n || cents > 100_000_000n || cents < -100_000_000n) return new Response('amount out of range', { status: 400, headers: cors });

  const supabase = createClient(supabaseUrl, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const rawEvent = Object.fromEntries(url.searchParams.entries());
  try {
    if (cents > 0n) {
      const { error } = await supabase.rpc('credit_offerwall_conversion', {
        p_provider: 'offerwall_gg', p_conversion_id: tx, p_user_id: user,
        p_gross_cents: cents.toString(), p_raw_event: rawEvent,
      });
      if (error) throw error;
    } else {
      const { error } = await supabase.rpc('apply_offerwall_reversal', {
        p_provider: 'offerwall_gg', p_conversion_id: tx, p_user_id: user, p_raw_event: rawEvent,
      });
      if (error) throw error;
    }
    return new Response('ok', { status: 200, headers: cors });
  } catch (e) {
    console.error('Offerwall.GG postback failed', e);
    return new Response('processing failed', { status: 500, headers: cors });
  }
});
