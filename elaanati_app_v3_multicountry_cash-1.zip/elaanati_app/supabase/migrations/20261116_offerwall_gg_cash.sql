-- Offerwall.GG cash callback, reversals, and cash-agent reconciliation.
-- Run after 20261115_cash_wallet.sql. Configure the Offerwall.GG placement currency as USD.

alter table public.cash_wallets
  add column if not exists recovery_cents bigint not null default 0 check (recovery_cents >= 0);

alter table public.cash_withdrawal_requests
  add column if not exists cash_delivered_at timestamptz;

create unique index if not exists one_open_cash_withdrawal_per_user
  on public.cash_withdrawal_requests(user_id)
  where status in ('pending_agent','agent_verified');

-- Future confirmed earnings first repay reversals/chargebacks, then become withdrawable.
create or replace function public.credit_offerwall_conversion(
  p_provider text, p_conversion_id text, p_user_id uuid,
  p_gross_cents bigint, p_raw_event jsonb default '{}'::jsonb
) returns boolean
language plpgsql security definer set search_path=public,auth
as $$
declare
  v_inserted uuid;
  v_recovery bigint;
  v_offset bigint;
  v_net bigint;
begin
  if coalesce(auth.role(),'') <> 'service_role' then raise exception 'server role required'; end if;
  if coalesce(trim(p_provider),'')='' or coalesce(trim(p_conversion_id),'')='' then raise exception 'provider and conversion id are required'; end if;
  if p_gross_cents <= 0 then raise exception 'conversion amount must be positive'; end if;
  if not exists(select 1 from public.profiles where id=p_user_id and role='user' and is_suspended=false) then raise exception 'user is not eligible'; end if;

  insert into public.offerwall_conversions(provider,provider_conversion_id,user_id,gross_cents,raw_event)
  values(trim(p_provider),trim(p_conversion_id),p_user_id,p_gross_cents,coalesce(p_raw_event,'{}'::jsonb))
  on conflict(provider,provider_conversion_id) do nothing returning id into v_inserted;
  if v_inserted is null then return false; end if;

  insert into public.cash_wallets(user_id) values(p_user_id) on conflict do nothing;
  select recovery_cents into v_recovery from public.cash_wallets where user_id=p_user_id for update;
  v_offset := least(v_recovery,p_gross_cents);
  v_net := p_gross_cents-v_offset;
  update public.cash_wallets
    set recovery_cents=recovery_cents-v_offset,
        available_cents=available_cents+v_net,
        updated_at=now()
    where user_id=p_user_id;
  if v_net > 0 then
    insert into public.cash_ledger(user_id,amount_cents,entry_type,reference_id,note)
    values(p_user_id,v_net,'offerwall_credit',trim(p_provider)||':'||trim(p_conversion_id),
      case when v_offset>0 then 'مكافأة مؤكدة بعد خصم تسوية استرداد سابقة' else 'مكافأة عرض مؤكدة من Offerwall.GG' end);
  end if;
  return true;
end; $$;

create or replace function public.apply_offerwall_reversal(
  p_provider text, p_conversion_id text, p_user_id uuid, p_raw_event jsonb default '{}'::jsonb
) returns boolean
language plpgsql security definer set search_path=public,auth
as $$
declare
  v_conversion public.offerwall_conversions%rowtype;
  v_take bigint;
  v_debt bigint;
begin
  if coalesce(auth.role(),'') <> 'service_role' then raise exception 'server role required'; end if;
  select * into v_conversion from public.offerwall_conversions
    where provider=trim(p_provider) and provider_conversion_id=trim(p_conversion_id)
    for update;
  if v_conversion.id is null then raise exception 'original conversion not found'; end if;
  if v_conversion.user_id<>p_user_id then raise exception 'conversion user mismatch'; end if;
  if v_conversion.status='reversed' then return false; end if;

  update public.offerwall_conversions set status='reversed',raw_event=coalesce(p_raw_event,'{}'::jsonb)
    where id=v_conversion.id;
  select least(available_cents,v_conversion.gross_cents),
         greatest(v_conversion.gross_cents-available_cents,0)
    into v_take,v_debt
    from public.cash_wallets where user_id=v_conversion.user_id for update;
  update public.cash_wallets
    set available_cents=available_cents-v_take,
        recovery_cents=recovery_cents+v_debt,
        updated_at=now()
    where user_id=v_conversion.user_id;
  insert into public.cash_ledger(user_id,amount_cents,entry_type,reference_id,note)
    values(v_conversion.user_id,-v_conversion.gross_cents,'chargeback',trim(p_provider)||':'||trim(p_conversion_id),
      'استرداد من مزود المكافآت؛ يخصم من الرصيد المتاح وأي فرق يسوى من الأرباح القادمة');
  return true;
end; $$;

create or replace function public.agent_review_cash_withdrawal(
  p_request_id uuid, p_decision text, p_note text default null, p_delivery_details jsonb default '{}'::jsonb
) returns void language plpgsql security definer set search_path=public
as $$
declare v_req public.cash_withdrawal_requests%rowtype;
begin
  if p_decision not in ('verified','rejected','cash_delivered') then raise exception 'قرار غير صالح'; end if;
  select * into v_req from public.cash_withdrawal_requests where id=p_request_id for update;
  if v_req.id is null or not public.is_my_agent(v_req.agent_id) then raise exception 'غير مصرح بهذا الطلب'; end if;

  if p_decision='verified' then
    if v_req.status<>'pending_agent' then raise exception 'حالة الطلب لا تسمح بالتحقق'; end if;
    update public.cash_withdrawal_requests set status='agent_verified',agent_note=p_note,reviewed_by_agent=auth.uid(),updated_at=now() where id=p_request_id;
  elsif p_decision='cash_delivered' then
    if v_req.status<>'agent_verified' or v_req.cash_delivered_at is not null then raise exception 'يجب التحقق من الطلب أولاً ولم يسبق تأكيد التسليم'; end if;
    if exists(select 1 from public.cash_wallets where user_id=v_req.user_id and recovery_cents>0) then raise exception 'يوجد استرداد معلق؛ لا تسلم النقد قبل مراجعة الأدمن'; end if;
    update public.cash_withdrawal_requests set cash_delivered_at=now(),agent_note=coalesce(p_note,agent_note),payout_details=coalesce(payout_details,'{}'::jsonb)||jsonb_build_object('cash_delivery',coalesce(p_delivery_details,'{}'::jsonb)),updated_at=now() where id=p_request_id;
  else
    if v_req.status<>'pending_agent' then raise exception 'لا يمكن رفض الطلب بعد التحقق'; end if;
    update public.cash_wallets set available_cents=available_cents+v_req.amount_cents,held_cents=held_cents-v_req.amount_cents,updated_at=now()
      where user_id=v_req.user_id and held_cents>=v_req.amount_cents;
    if not found then raise exception 'تعذر تحرير المبلغ المحجوز'; end if;
    update public.cash_withdrawal_requests set status='agent_rejected',agent_note=p_note,reviewed_by_agent=auth.uid(),updated_at=now() where id=p_request_id;
    insert into public.cash_ledger(user_id,amount_cents,entry_type,reference_id,note,actor_id)
      values(v_req.user_id,v_req.amount_cents,'withdrawal_release',v_req.id::text,coalesce(p_note,'رفض الوكيل وإرجاع المبلغ'),auth.uid());
  end if;
end; $$;

create or replace function public.admin_finalize_cash_withdrawal(
  p_request_id uuid, p_decision text, p_note text default null
) returns void language plpgsql security definer set search_path=public
as $$
declare v_req public.cash_withdrawal_requests%rowtype; v_recovery bigint;
begin
  if not public.is_admin() then raise exception 'صلاحية الأدمن مطلوبة'; end if;
  if p_decision not in ('paid','rejected') then raise exception 'قرار غير صالح'; end if;
  select * into v_req from public.cash_withdrawal_requests where id=p_request_id for update;
  if v_req.id is null or v_req.status<>'agent_verified' then raise exception 'يجب تحقق الوكيل أولاً'; end if;
  if p_decision='paid' and v_req.cash_delivered_at is null then raise exception 'يجب أن يؤكد الوكيل تسليم النقد أولاً'; end if;
  select recovery_cents into v_recovery from public.cash_wallets where user_id=v_req.user_id for update;
  if p_decision='paid' then
    if v_recovery>0 then raise exception 'يوجد رصيد استرداد معلق؛ لا يمكن اعتماد التسوية حالياً'; end if;
    update public.cash_wallets set held_cents=held_cents-v_req.amount_cents,updated_at=now()
      where user_id=v_req.user_id and held_cents>=v_req.amount_cents;
    if not found then raise exception 'الرصيد المحجوز غير كافٍ'; end if;
    update public.cash_withdrawal_requests set status='paid',admin_note=p_note,finalized_by_admin=auth.uid(),updated_at=now() where id=p_request_id;
    insert into public.cash_ledger(user_id,amount_cents,entry_type,reference_id,note,actor_id)
      values(v_req.user_id,-v_req.amount_cents,'withdrawal_paid',v_req.id::text,coalesce(p_note,'اعتماد تسليم النقد من الأدمن'),auth.uid());
  else
    update public.cash_wallets set available_cents=available_cents+v_req.amount_cents,held_cents=held_cents-v_req.amount_cents,updated_at=now()
      where user_id=v_req.user_id and held_cents>=v_req.amount_cents;
    if not found then raise exception 'تعذر تحرير المبلغ المحجوز'; end if;
    update public.cash_withdrawal_requests set status='rejected',admin_note=p_note,finalized_by_admin=auth.uid(),updated_at=now() where id=p_request_id;
    insert into public.cash_ledger(user_id,amount_cents,entry_type,reference_id,note,actor_id)
      values(v_req.user_id,v_req.amount_cents,'withdrawal_release',v_req.id::text,coalesce(p_note,'رفض الأدمن وإرجاع الرصيد'),auth.uid());
  end if;
end; $$;

revoke all on function public.apply_offerwall_reversal(text,text,uuid,jsonb) from public,anon,authenticated;
grant execute on function public.apply_offerwall_reversal(text,text,uuid,jsonb) to service_role;
revoke all on function public.credit_offerwall_conversion(text,text,uuid,bigint,jsonb) from public,anon,authenticated;
grant execute on function public.credit_offerwall_conversion(text,text,uuid,bigint,jsonb) to service_role;

-- Do not let a user request more cash while a reversal recovery is outstanding.
create or replace function public.submit_cash_withdrawal(
  p_amount_cents bigint, p_method text, p_details jsonb default '{}'::jsonb
) returns uuid
language plpgsql security definer set search_path=public
as $$
declare v_profile public.profiles%rowtype; v_wallet public.cash_wallets%rowtype; v_id uuid;
begin
  select * into v_profile from public.profiles where id=auth.uid() for update;
  if v_profile.id is null or v_profile.role<>'user' or v_profile.is_suspended then raise exception 'الحساب غير مؤهل للسحب'; end if;
  if v_profile.agent_id is null then raise exception 'يجب الارتباط بوكيل قبل السحب'; end if;
  if p_amount_cents < 500 then raise exception 'الحد الأدنى للسحب 5.00 USD'; end if;
  if p_method not in ('bank_transfer','paypal','cash_agent','other') then raise exception 'طريقة السحب غير مدعومة'; end if;
  select * into v_wallet from public.cash_wallets where user_id=auth.uid() for update;
  if v_wallet.recovery_cents>0 then raise exception 'توجد تسوية استرداد معلقة؛ ستذهب الأرباح القادمة لتغطيتها أولاً'; end if;
  if v_wallet.available_cents < p_amount_cents then raise exception 'الرصيد المتاح غير كافٍ'; end if;
  update public.cash_wallets set available_cents=available_cents-p_amount_cents,held_cents=held_cents+p_amount_cents,updated_at=now() where user_id=auth.uid();
  insert into public.cash_withdrawal_requests(user_id,agent_id,amount_cents,payout_method,payout_details)
    values(auth.uid(),v_profile.agent_id,p_amount_cents,p_method,coalesce(p_details,'{}'::jsonb)) returning id into v_id;
  insert into public.cash_ledger(user_id,amount_cents,entry_type,reference_id,note,actor_id)
    values(auth.uid(),-p_amount_cents,'withdrawal_hold',v_id::text,'حجز مبلغ لطلب سحب نقدي من الوكيل',auth.uid());
  return v_id;
end; $$;

-- Prevent the agent from recording a cash handover while an outstanding reversal is known.
-- Prevent admin rejection after the agent has recorded physical cash delivery.
create or replace function public.admin_finalize_cash_withdrawal(
  p_request_id uuid, p_decision text, p_note text default null
) returns void language plpgsql security definer set search_path=public
as $$
declare v_req public.cash_withdrawal_requests%rowtype; v_recovery bigint;
begin
  if not public.is_admin() then raise exception 'صلاحية الأدمن مطلوبة'; end if;
  if p_decision not in ('paid','rejected') then raise exception 'قرار غير صالح'; end if;
  select * into v_req from public.cash_withdrawal_requests where id=p_request_id for update;
  if v_req.id is null or v_req.status<>'agent_verified' then raise exception 'يجب تحقق الوكيل أولاً'; end if;
  if p_decision='paid' then
    if v_req.cash_delivered_at is null then raise exception 'لم يؤكد الوكيل تسليم النقد بعد'; end if;
    select recovery_cents into v_recovery from public.cash_wallets where user_id=v_req.user_id for update;
    if v_recovery>0 then raise exception 'يوجد رصيد استرداد معلق؛ يلزم إجراء مراجعة إدارية قبل إقفال التسوية'; end if;
    update public.cash_wallets set held_cents=held_cents-v_req.amount_cents,updated_at=now()
      where user_id=v_req.user_id and held_cents>=v_req.amount_cents;
    if not found then raise exception 'الرصيد المحجوز غير كافٍ'; end if;
    update public.cash_withdrawal_requests set status='paid',admin_note=p_note,finalized_by_admin=auth.uid(),updated_at=now() where id=p_request_id;
    insert into public.cash_ledger(user_id,amount_cents,entry_type,reference_id,note,actor_id)
      values(v_req.user_id,-v_req.amount_cents,'withdrawal_paid',v_req.id::text,coalesce(p_note,'اعتماد تسليم النقد من الأدمن'),auth.uid());
  else
    if v_req.cash_delivered_at is not null then raise exception 'تم تسليم النقد بالفعل؛ لا يمكن رفض التسوية من هنا'; end if;
    update public.cash_wallets set available_cents=available_cents+v_req.amount_cents,held_cents=held_cents-v_req.amount_cents,updated_at=now()
      where user_id=v_req.user_id and held_cents>=v_req.amount_cents;
    if not found then raise exception 'تعذر تحرير المبلغ المحجوز'; end if;
    update public.cash_withdrawal_requests set status='rejected',admin_note=p_note,finalized_by_admin=auth.uid(),updated_at=now() where id=p_request_id;
    insert into public.cash_ledger(user_id,amount_cents,entry_type,reference_id,note,actor_id)
      values(v_req.user_id,v_req.amount_cents,'withdrawal_release',v_req.id::text,coalesce(p_note,'رفض الأدمن وإرجاع الرصيد'),auth.uid());
  end if;
end; $$;

-- Force authenticated agents onto the structured delivery RPC; never expose a bypassing old overload.
revoke all on function public.agent_review_cash_withdrawal(uuid,text,text) from public,anon,authenticated;
revoke all on function public.agent_review_cash_withdrawal(uuid,text,text,jsonb) from public,anon,authenticated;
grant execute on function public.agent_review_cash_withdrawal(uuid,text,text,jsonb) to authenticated;

create or replace function public.admin_adjust_cash_wallet(
  p_user_id uuid, p_amount_cents bigint, p_note text
) returns void language plpgsql security definer set search_path=public
as $$
declare v_wallet public.cash_wallets%rowtype;
begin
  if not public.is_admin() then raise exception 'صلاحية الأدمن مطلوبة'; end if;
  if p_amount_cents=0 then raise exception 'المبلغ لا يمكن أن يكون صفراً'; end if;
  if coalesce(trim(p_note),'')='' then raise exception 'سبب التعديل مطلوب'; end if;
  select * into v_wallet from public.cash_wallets where user_id=p_user_id for update;
  if v_wallet.user_id is null then raise exception 'المحفظة غير موجودة'; end if;
  if v_wallet.available_cents+p_amount_cents<0 then raise exception 'لا يمكن أن يصبح الرصيد المتاح سالباً'; end if;
  update public.cash_wallets set available_cents=available_cents+p_amount_cents,updated_at=now() where user_id=p_user_id;
  insert into public.cash_ledger(user_id,amount_cents,entry_type,note,actor_id)
    values(p_user_id,p_amount_cents,'admin_adjustment',p_note,auth.uid());
end; $$;
revoke all on function public.admin_adjust_cash_wallet(uuid,bigint,text) from public,anon;
grant execute on function public.admin_adjust_cash_wallet(uuid,bigint,text) to authenticated;
