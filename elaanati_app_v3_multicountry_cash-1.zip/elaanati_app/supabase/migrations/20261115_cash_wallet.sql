-- Cash wallet extension for Elaanati.
-- Monetary values are integer cents (USD) to avoid floating-point errors.
-- Apply only after supabase/schema.sql.

create type public.cash_withdrawal_status as enum
  ('pending_agent','agent_verified','agent_rejected','paid','rejected');

create table public.cash_wallets (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  currency char(3) not null default 'USD' check (currency='USD'),
  available_cents bigint not null default 0 check (available_cents >= 0),
  held_cents bigint not null default 0 check (held_cents >= 0),
  updated_at timestamptz not null default now()
);

create table public.cash_ledger (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id),
  amount_cents bigint not null check (amount_cents <> 0),
  entry_type text not null check (entry_type in
    ('offerwall_credit','withdrawal_hold','withdrawal_release','withdrawal_paid','admin_adjustment','chargeback')),
  reference_id text,
  note text,
  actor_id uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table public.offerwall_conversions (
  id uuid primary key default gen_random_uuid(),
  provider text not null,
  provider_conversion_id text not null,
  user_id uuid not null references public.profiles(id),
  gross_cents bigint not null check (gross_cents > 0),
  currency char(3) not null default 'USD' check (currency='USD'),
  status text not null default 'approved' check (status in ('approved','reversed')),
  raw_event jsonb not null default '{}'::jsonb,
  received_at timestamptz not null default now(),
  unique(provider, provider_conversion_id)
);

create table public.cash_withdrawal_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id),
  agent_id uuid not null references public.agents(id),
  amount_cents bigint not null check (amount_cents >= 500),
  currency char(3) not null default 'USD' check (currency='USD'),
  payout_method text not null check (payout_method in ('bank_transfer','paypal','cash_agent','other')),
  payout_details jsonb not null default '{}'::jsonb,
  status public.cash_withdrawal_status not null default 'pending_agent',
  agent_note text,
  admin_note text,
  reviewed_by_agent uuid references auth.users(id),
  finalized_by_admin uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index cash_ledger_user_created_idx on public.cash_ledger(user_id, created_at desc);
create index cash_withdrawals_agent_status_idx on public.cash_withdrawal_requests(agent_id,status,created_at desc);
create index offerwall_user_created_idx on public.offerwall_conversions(user_id,received_at desc);

-- Create a wallet for each profile, including profiles that already exist.
insert into public.cash_wallets(user_id)
select id from public.profiles on conflict do nothing;

create or replace function public.create_cash_wallet_for_profile()
returns trigger language plpgsql security definer set search_path=public
as $$ begin
  insert into public.cash_wallets(user_id) values(new.id) on conflict do nothing;
  return new;
end; $$;
create trigger profile_cash_wallet after insert on public.profiles
for each row execute procedure public.create_cash_wallet_for_profile();

alter table public.cash_wallets enable row level security;
alter table public.cash_ledger enable row level security;
alter table public.offerwall_conversions enable row level security;
alter table public.cash_withdrawal_requests enable row level security;

create policy "cash wallet own or admin" on public.cash_wallets for select to authenticated
using (user_id=auth.uid() or public.is_admin());
create policy "cash ledger own or admin" on public.cash_ledger for select to authenticated
using (user_id=auth.uid() or public.is_admin());
create policy "cash withdrawals scoped" on public.cash_withdrawal_requests for select to authenticated
using (user_id=auth.uid() or public.is_admin() or public.is_my_agent(agent_id));
-- No client read/write policy for raw provider conversion events.

-- Called only by a trusted server-side adapter AFTER provider signature validation.
-- The provider-specific signature format must be implemented in the Edge Function.
create or replace function public.credit_offerwall_conversion(
  p_provider text, p_conversion_id text, p_user_id uuid,
  p_gross_cents bigint, p_raw_event jsonb default '{}'::jsonb
) returns boolean
language plpgsql security definer set search_path=public,auth
as $$
declare v_inserted uuid;
begin
  if coalesce(auth.role(),'') <> 'service_role' then raise exception 'server role required'; end if;
  if p_provider is null or length(trim(p_provider))=0 or p_conversion_id is null or length(trim(p_conversion_id))=0 then
    raise exception 'provider and conversion id are required';
  end if;
  if p_gross_cents <= 0 then raise exception 'conversion amount must be positive'; end if;
  if not exists(select 1 from public.profiles where id=p_user_id and role='user' and is_suspended=false) then
    raise exception 'user is not eligible';
  end if;
  insert into public.offerwall_conversions(provider,provider_conversion_id,user_id,gross_cents,raw_event)
  values(trim(p_provider),trim(p_conversion_id),p_user_id,p_gross_cents,coalesce(p_raw_event,'{}'::jsonb))
  on conflict(provider,provider_conversion_id) do nothing
  returning id into v_inserted;
  if v_inserted is null then return false; end if;
  insert into public.cash_wallets(user_id,available_cents) values(p_user_id,p_gross_cents)
  on conflict(user_id) do update set available_cents=public.cash_wallets.available_cents+excluded.available_cents, updated_at=now();
  insert into public.cash_ledger(user_id,amount_cents,entry_type,reference_id,note)
  values(p_user_id,p_gross_cents,'offerwall_credit',p_provider||':'||p_conversion_id,'مكافأة عرض مؤكدة من مزود المكافآت');
  return true;
end; $$;

create or replace function public.submit_cash_withdrawal(
  p_amount_cents bigint, p_method text, p_details jsonb default '{}'::jsonb
) returns uuid
language plpgsql security definer set search_path=public
as $$
declare v_profile public.profiles%rowtype; v_wallet public.cash_wallets%rowtype; v_id uuid;
begin
  select * into v_profile from public.profiles where id=auth.uid() for update;
  if v_profile.id is null or v_profile.role<>'user' or v_profile.is_suspended then raise exception 'الحساب غير مؤهل للسحب'; end if;
  if v_profile.agent_id is null then raise exception 'يجب الارتباط بوكيل قبل السحب'; end if;
  if p_amount_cents < 500 then raise exception 'الحد الأدنى للسحب 5.00 USD'; end if;
  if p_method not in ('bank_transfer','paypal','cash_agent','other') then raise exception 'طريقة السحب غير مدعومة'; end if;
  select * into v_wallet from public.cash_wallets where user_id=auth.uid() for update;
  if v_wallet.available_cents < p_amount_cents then raise exception 'الرصيد المتاح غير كافٍ'; end if;
  update public.cash_wallets set available_cents=available_cents-p_amount_cents, held_cents=held_cents+p_amount_cents, updated_at=now() where user_id=auth.uid();
  insert into public.cash_withdrawal_requests(user_id,agent_id,amount_cents,payout_method,payout_details)
  values(auth.uid(),v_profile.agent_id,p_amount_cents,p_method,coalesce(p_details,'{}'::jsonb)) returning id into v_id;
  insert into public.cash_ledger(user_id,amount_cents,entry_type,reference_id,note,actor_id)
  values(auth.uid(),-p_amount_cents,'withdrawal_hold',v_id::text,'حجز مبلغ لطلب سحب',auth.uid());
  return v_id;
end; $$;

create or replace function public.agent_review_cash_withdrawal(
  p_request_id uuid, p_decision text, p_note text default null
) returns void language plpgsql security definer set search_path=public
as $$
declare v_req public.cash_withdrawal_requests%rowtype;
begin
  if p_decision not in ('verified','rejected') then raise exception 'قرار غير صالح'; end if;
  select * into v_req from public.cash_withdrawal_requests where id=p_request_id for update;
  if v_req.id is null or not public.is_my_agent(v_req.agent_id) then raise exception 'غير مصرح بهذا الطلب'; end if;
  if v_req.status<>'pending_agent' then raise exception 'تمت مراجعة الطلب مسبقاً'; end if;
  if p_decision='verified' then
    update public.cash_withdrawal_requests set status='agent_verified',agent_note=p_note,reviewed_by_agent=auth.uid(),updated_at=now() where id=p_request_id;
  else
    update public.cash_wallets set available_cents=available_cents+v_req.amount_cents,held_cents=held_cents-v_req.amount_cents,updated_at=now() where user_id=v_req.user_id and held_cents>=v_req.amount_cents;
    if not found then raise exception 'تعذر تحرير المبلغ المحجوز'; end if;
    update public.cash_withdrawal_requests set status='agent_rejected',agent_note=p_note,reviewed_by_agent=auth.uid(),updated_at=now() where id=p_request_id;
    insert into public.cash_ledger(user_id,amount_cents,entry_type,reference_id,note,actor_id)
    values(v_req.user_id,v_req.amount_cents,'withdrawal_release',v_req.id::text,coalesce(p_note,'رفض الوكيل وإرجاع المبلغ'),auth.uid());
  end if;
end; $$;

create or replace function public.admin_finalize_cash_withdrawal(
  p_request_id uuid, p_decision text, p_note text default null
) returns void language plpgsql security definer set search_path=public
as $$
declare v_req public.cash_withdrawal_requests%rowtype;
begin
  if not public.is_admin() then raise exception 'صلاحية الأدمن مطلوبة'; end if;
  if p_decision not in ('paid','rejected') then raise exception 'قرار غير صالح'; end if;
  select * into v_req from public.cash_withdrawal_requests where id=p_request_id for update;
  if v_req.id is null or v_req.status<>'agent_verified' then raise exception 'يجب تحقق الوكيل أولاً'; end if;
  if p_decision='paid' then
    update public.cash_wallets set held_cents=held_cents-v_req.amount_cents,updated_at=now() where user_id=v_req.user_id and held_cents>=v_req.amount_cents;
    if not found then raise exception 'الرصيد المحجوز غير كافٍ'; end if;
    update public.cash_withdrawal_requests set status='paid',admin_note=p_note,finalized_by_admin=auth.uid(),updated_at=now() where id=p_request_id;
    insert into public.cash_ledger(user_id,amount_cents,entry_type,reference_id,note,actor_id)
    values(v_req.user_id,-v_req.amount_cents,'withdrawal_paid',v_req.id::text,coalesce(p_note,'تم تأكيد الصرف من الأدمن'),auth.uid());
  else
    update public.cash_wallets set available_cents=available_cents+v_req.amount_cents,held_cents=held_cents-v_req.amount_cents,updated_at=now() where user_id=v_req.user_id and held_cents>=v_req.amount_cents;
    if not found then raise exception 'تعذر تحرير المبلغ المحجوز'; end if;
    update public.cash_withdrawal_requests set status='rejected',admin_note=p_note,finalized_by_admin=auth.uid(),updated_at=now() where id=p_request_id;
    insert into public.cash_ledger(user_id,amount_cents,entry_type,reference_id,note,actor_id)
    values(v_req.user_id,v_req.amount_cents,'withdrawal_release',v_req.id::text,coalesce(p_note,'رفض الأدمن وإرجاع المبلغ'),auth.uid());
  end if;
end; $$;

revoke all on function public.credit_offerwall_conversion(text,text,uuid,bigint,jsonb) from public, anon, authenticated;
grant execute on function public.credit_offerwall_conversion(text,text,uuid,bigint,jsonb) to service_role;
revoke all on function public.submit_cash_withdrawal(bigint,text,jsonb) from public;
revoke all on function public.agent_review_cash_withdrawal(uuid,text,text) from public;
revoke all on function public.admin_finalize_cash_withdrawal(uuid,text,text) from public;
grant execute on function public.submit_cash_withdrawal(bigint,text,jsonb) to authenticated;
grant execute on function public.agent_review_cash_withdrawal(uuid,text,text) to authenticated;
grant execute on function public.admin_finalize_cash_withdrawal(uuid,text,text) to authenticated;
