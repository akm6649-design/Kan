-- Elaanati secure database schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create type public.app_role as enum ('user','agent','admin');
create type public.withdrawal_status as enum ('pending','agent_verified','agent_rejected','paid','rejected');

create table public.agents (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  agent_code text not null unique,
  display_name text not null,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  public_id text not null unique,
  display_name text,
  role public.app_role not null default 'user',
  agent_id uuid references public.agents(id),
  points bigint not null default 0 check (points >= 0),
  is_suspended boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.point_ledger (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id),
  amount bigint not null check (amount <> 0),
  entry_type text not null check (entry_type in ('admin_credit','admin_debit','ad_reward','withdrawal_reserve','withdrawal_release','withdrawal_paid','adjustment')),
  reference_id uuid,
  note text,
  actor_id uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table public.withdrawal_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id),
  agent_id uuid not null references public.agents(id),
  points bigint not null check (points > 0),
  status public.withdrawal_status not null default 'pending',
  agent_note text,
  admin_note text,
  reviewed_by_agent uuid references auth.users(id),
  finalized_by_admin uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index profiles_agent_id_idx on public.profiles(agent_id);
create index ledger_user_created_idx on public.point_ledger(user_id, created_at desc);
create index withdrawals_agent_status_idx on public.withdrawal_requests(agent_id, status, created_at desc);

create or replace function public.current_role() returns public.app_role
language sql stable security definer set search_path=public
as $$ select role from public.profiles where id=auth.uid() $$;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path=public
as $$ select coalesce(public.current_role()='admin',false) $$;

create or replace function public.is_my_agent(p_agent_id uuid) returns boolean
language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.agents where id=p_agent_id and user_id=auth.uid() and is_active) $$;

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path=public,auth
as $$
declare v_code text; v_agent uuid; v_name text;
begin
  v_code := nullif(trim(new.raw_user_meta_data->>'agent_code'),'');
  v_name := nullif(trim(new.raw_user_meta_data->>'display_name'),'');
  if v_code is not null then
    select id into v_agent from public.agents where agent_code=v_code and is_active=true;
    if v_agent is null then raise exception 'كود الوكيل غير صحيح أو غير فعال'; end if;
  end if;
  insert into public.profiles(id,public_id,display_name,agent_id)
  values(new.id,'PT-'||upper(substr(replace(new.id::text,'-',''),1,10)),v_name,v_agent);
  return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.agents enable row level security;
alter table public.point_ledger enable row level security;
alter table public.withdrawal_requests enable row level security;

create policy "profiles read self agent scope admin" on public.profiles for select to authenticated
using (id=auth.uid() or public.is_admin() or (public.current_role()='agent' and agent_id in (select id from public.agents where user_id=auth.uid())));
create policy "agents read own or admin" on public.agents for select to authenticated
using (user_id=auth.uid() or public.is_admin());
create policy "ledger read self or admin" on public.point_ledger for select to authenticated
using (user_id=auth.uid() or public.is_admin());
create policy "withdrawals read scoped" on public.withdrawal_requests for select to authenticated
using (user_id=auth.uid() or public.is_admin() or public.is_my_agent(agent_id));
-- No direct client INSERT/UPDATE/DELETE policies on balances, ledger, requests or roles.

create or replace function public.submit_withdrawal(p_points bigint) returns uuid
language plpgsql security definer set search_path=public
as $$
declare v_profile public.profiles%rowtype; v_id uuid;
begin
  select * into v_profile from public.profiles where id=auth.uid() for update;
  if v_profile.id is null or v_profile.role<>'user' or v_profile.is_suspended then raise exception 'الحساب غير مؤهل لطلب السحب'; end if;
  if v_profile.agent_id is null then raise exception 'يجب التسجيل لدى وكيل قبل طلب السحب'; end if;
  if p_points<=0 or p_points>v_profile.points then raise exception 'رصيد النقاط غير كافٍ'; end if;
  update public.profiles set points=points-p_points where id=auth.uid();
  insert into public.withdrawal_requests(user_id,agent_id,points) values(auth.uid(),v_profile.agent_id,p_points) returning id into v_id;
  insert into public.point_ledger(user_id,amount,entry_type,reference_id,note,actor_id)
  values(auth.uid(),-p_points,'withdrawal_reserve',v_id,'حجز نقاط لطلب سحب',auth.uid());
  return v_id;
end; $$;

create or replace function public.agent_review_withdrawal(p_request_id uuid,p_decision text,p_note text default null) returns void
language plpgsql security definer set search_path=public
as $$
declare v_req public.withdrawal_requests%rowtype;
begin
  if p_decision not in ('verified','rejected') then raise exception 'قرار غير صالح'; end if;
  select * into v_req from public.withdrawal_requests where id=p_request_id for update;
  if v_req.id is null or not public.is_my_agent(v_req.agent_id) then raise exception 'غير مصرح بهذا الطلب'; end if;
  if v_req.status<>'pending' then raise exception 'تمت مراجعة الطلب مسبقاً'; end if;
  update public.withdrawal_requests set status=case when p_decision='verified' then 'agent_verified'::public.withdrawal_status else 'agent_rejected'::public.withdrawal_status end,
    agent_note=p_note,reviewed_by_agent=auth.uid(),updated_at=now() where id=p_request_id;
  if p_decision='rejected' then
    update public.profiles set points=points+v_req.points where id=v_req.user_id;
    insert into public.point_ledger(user_id,amount,entry_type,reference_id,note,actor_id)
    values(v_req.user_id,v_req.points,'withdrawal_release',v_req.id,coalesce(p_note,'إرجاع نقاط بعد رفض الوكيل'),auth.uid());
  end if;
end; $$;

create or replace function public.admin_finalize_withdrawal(p_request_id uuid,p_decision text,p_note text default null) returns void
language plpgsql security definer set search_path=public
as $$
declare v_req public.withdrawal_requests%rowtype;
begin
  if not public.is_admin() then raise exception 'صلاحية الأدمن مطلوبة'; end if;
  if p_decision not in ('paid','rejected') then raise exception 'قرار غير صالح'; end if;
  select * into v_req from public.withdrawal_requests where id=p_request_id for update;
  if v_req.id is null or v_req.status<>'agent_verified' then raise exception 'يجب أن يتحقق الوكيل من الطلب أولاً'; end if;
  update public.withdrawal_requests set status=p_decision::public.withdrawal_status,admin_note=p_note,finalized_by_admin=auth.uid(),updated_at=now() where id=p_request_id;
  if p_decision='paid' then
    insert into public.point_ledger(user_id,amount,entry_type,reference_id,note,actor_id)
    values(v_req.user_id,0,'withdrawal_paid',v_req.id,coalesce(p_note,'تم اعتماد الصرف'),auth.uid());
  else
    update public.profiles set points=points+v_req.points where id=v_req.user_id;
    insert into public.point_ledger(user_id,amount,entry_type,reference_id,note,actor_id)
    values(v_req.user_id,v_req.points,'withdrawal_release',v_req.id,coalesce(p_note,'إرجاع نقاط بعد رفض الأدمن'),auth.uid());
  end if;
end; $$;

create or replace function public.admin_set_suspension(p_user_id uuid,p_suspended boolean) returns void
language plpgsql security definer set search_path=public
as $$
begin
  if not public.is_admin() then raise exception 'صلاحية الأدمن مطلوبة'; end if;
  update public.profiles set is_suspended=p_suspended where id=p_user_id and role<>'admin';
  if not found then raise exception 'الحساب غير موجود أو لا يمكن تجميده'; end if;
end; $$;

create or replace function public.admin_adjust_points(p_user_id uuid,p_amount bigint,p_note text) returns void
language plpgsql security definer set search_path=public
as $$
declare v_points bigint;
begin
  if not public.is_admin() then raise exception 'صلاحية الأدمن مطلوبة'; end if;
  if p_amount=0 then raise exception 'المبلغ لا يمكن أن يكون صفراً'; end if;
  update public.profiles set points=points+p_amount where id=p_user_id and points+p_amount>=0 returning points into v_points;
  if not found then raise exception 'الحساب غير موجود أو الرصيد لا يسمح بالخصم'; end if;
  insert into public.point_ledger(user_id,amount,entry_type,note,actor_id)
  values(p_user_id,p_amount,case when p_amount>0 then 'admin_credit' else 'admin_debit' end,p_note,auth.uid());
end; $$;

revoke all on function public.submit_withdrawal(bigint) from public;
revoke all on function public.agent_review_withdrawal(uuid,text,text) from public;
revoke all on function public.admin_finalize_withdrawal(uuid,text,text) from public;
revoke all on function public.admin_set_suspension(uuid,boolean) from public;
revoke all on function public.admin_adjust_points(uuid,bigint,text) from public;
grant execute on function public.submit_withdrawal(bigint) to authenticated;
grant execute on function public.agent_review_withdrawal(uuid,text,text) to authenticated;
grant execute on function public.admin_finalize_withdrawal(uuid,text,text) to authenticated;
grant execute on function public.admin_set_suspension(uuid,boolean) to authenticated;
grant execute on function public.admin_adjust_points(uuid,bigint,text) to authenticated;
