import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');
const offerwallPublicKey = String.fromEnvironment('OFFERWALL_PUBLIC_KEY');
final supabaseReady = supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty;
final db = Supabase.instance.client;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (supabaseReady) await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  runApp(const ElaanatiApp());
}

class ElaanatiApp extends StatelessWidget {
  const ElaanatiApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'إعلاناتي',
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff1749d1)), useMaterial3: true, fontFamily: 'Arial'),
    home: supabaseReady ? const AuthGate() : const SetupScreen(),
  );
}

class SetupScreen extends StatelessWidget {
  const SetupScreen({super.key});
  @override
  Widget build(BuildContext context) => const Scaffold(body: Center(child: Padding(padding: EdgeInsets.all(24), child: Text('لتشغيل التطبيق، أضف مفاتيح Supabase العامة عبر --dart-define كما هو موضح في README.md', textAlign: TextAlign.center, textDirection: TextDirection.rtl))));
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<AuthState>(
    stream: db.auth.onAuthStateChange,
    builder: (context, snapshot) => db.auth.currentSession == null ? const LoginScreen() : const RoleHome(),
  );
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override State<LoginScreen> createState() => _LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen> {
  final email = TextEditingController(), password = TextEditingController(), name = TextEditingController(), agent = TextEditingController();
  bool register = false, busy = false; String? error;
  Future<void> submit() async {
    setState(() { busy = true; error = null; });
    try {
      if (register) {
        await db.auth.signUp(email: email.text.trim(), password: password.text, data: {'display_name': name.text.trim(), 'agent_code': agent.text.trim().isEmpty ? null : agent.text.trim()});
      } else {
        await db.auth.signInWithPassword(email: email.text.trim(), password: password.text);
      }
    } on AuthException catch (e) { error = e.message; } catch (e) { error = 'تعذر إكمال العملية: $e'; }
    if (mounted) setState(() => busy = false);
  }
  @override Widget build(BuildContext context) => Scaffold(body: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 440), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    const Icon(Icons.workspace_premium, size: 72, color: Color(0xffffbf24)), const Text('إعلاناتي', textAlign: TextAlign.center, style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)), const SizedBox(height: 24),
    if (register) TextField(controller: name, decoration: const InputDecoration(labelText: 'الاسم', border: OutlineInputBorder())), if (register) const SizedBox(height: 12),
    TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'البريد الإلكتروني', border: OutlineInputBorder())), const SizedBox(height: 12),
    TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'كلمة المرور', border: OutlineInputBorder())),
    if (register) ...[const SizedBox(height: 12), TextField(controller: agent, decoration: const InputDecoration(labelText: 'كود الوكيل (اختياري)', border: OutlineInputBorder()))],
    if (error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(error!, style: const TextStyle(color: Colors.red), textAlign: TextAlign.center)), const SizedBox(height: 18),
    FilledButton(onPressed: busy ? null : submit, child: Text(busy ? 'يرجى الانتظار...' : register ? 'إنشاء حساب' : 'تسجيل الدخول')),
    TextButton(onPressed: () => setState(() => register = !register), child: Text(register ? 'لديك حساب؟ تسجيل الدخول' : 'إنشاء حساب جديد')),
  ])))));
}

class RoleHome extends StatefulWidget { const RoleHome({super.key}); @override State<RoleHome> createState() => _RoleHomeState(); }
class _RoleHomeState extends State<RoleHome> {
  Map<String, dynamic>? profile; bool loading = true; String? error;
  @override void initState() { super.initState(); load(); }
  Future<void> load() async {
    try { final id = db.auth.currentUser!.id; profile = await db.from('profiles').select('id,display_name,role,points,agent_id,public_id').eq('id', id).single(); }
    catch (e) { error = '$e'; }
    if (mounted) setState(() => loading = false);
  }
  Future<void> logout() async => db.auth.signOut();
  @override Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (error != null) return Scaffold(body: Center(child: Padding(padding: const EdgeInsets.all(20), child: Text('تعذر تحميل الحساب: $error'))));
    final role = profile?['role'];
    return Scaffold(appBar: AppBar(title: const Text('إعلاناتي'), actions: [IconButton(onPressed: logout, icon: const Icon(Icons.logout))]), body: RefreshIndicator(onRefresh: load, child: ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('مرحباً، ${profile?['display_name'] ?? 'مستخدم'}', style: Theme.of(context).textTheme.titleLarge), const SizedBox(height: 8), Text('ID: ${profile?['public_id']}'), Text('الدور: $role'), const SizedBox(height: 8), Text('رصيد النقاط الداخلية: ${profile?['points'] ?? 0}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xff1749d1)))]))),
      if (role == 'user') UserCashPanel(profile: profile!), if (role == 'agent') const AgentCashPanel(), if (role == 'admin') const AdminCashPanel(),
    ]))));
  }
}

String money(dynamic cents) => '\$${((cents as num? ?? 0) / 100).toStringAsFixed(2)}';
Map<String, dynamic>? walletOf(dynamic raw) { if (raw is List && raw.isNotEmpty && raw.first is Map) return Map<String, dynamic>.from(raw.first as Map); return null; }
String statusLabel(String s) => switch (s) { 'pending_agent' => 'بانتظار مراجعة الوكيل', 'agent_verified' => 'تم التحقق - بانتظار اعتماد الأدمن', 'agent_rejected' => 'رفض الوكيل', 'paid' => 'تم الصرف نقداً', 'rejected' => 'مرفوض من الأدمن', _ => s };

class UserCashPanel extends StatefulWidget {
  const UserCashPanel({super.key, required this.profile}); final Map<String, dynamic> profile;
  @override State<UserCashPanel> createState() => _UserCashPanelState();
}
class _UserCashPanelState extends State<UserCashPanel> {
  final amount = TextEditingController(); bool loading = true, busy = false; Map<String, dynamic> wallet = {}; List<dynamic> ledger = [], requests = []; String message = '';
  @override void initState() { super.initState(); load(); }
  Future<void> load() async {
    try {
      final uid = db.auth.currentUser!.id;
      wallet = await db.from('cash_wallets').select('available_cents,held_cents,recovery_cents,currency').eq('user_id', uid).single();
      ledger = await db.from('cash_ledger').select('amount_cents,entry_type,note,created_at').eq('user_id', uid).order('created_at', ascending: false).limit(12);
      requests = await db.from('cash_withdrawal_requests').select('id,amount_cents,status,created_at,agent_note,admin_note').eq('user_id', uid).order('created_at', ascending: false).limit(10);
    } catch (e) { message = 'تعذر تحميل المحفظة: $e'; }
    if (mounted) setState(() => loading = false);
  }
  Future<void> withdraw() async {
    final value = double.tryParse(amount.text.replaceAll(',', '.'));
    if (value == null || value < 5) { setState(() => message = 'الحد الأدنى لطلب السحب 5.00 دولار'); return; }
    setState(() { busy = true; message = ''; });
    try {
      await db.rpc('submit_cash_withdrawal', params: {'p_amount_cents': (value * 100).round(), 'p_method': 'cash_agent', 'p_details': {'delivery': 'cash_at_registered_agent'}});
      amount.clear(); message = 'تم إرسال طلبك إلى الوكيل المرتبط بحسابك. راجع الوكيل لاستلام النقد بعد التحقق.'; await load();
    } catch (e) { message = 'تعذر إرسال الطلب: $e'; }
    if (mounted) setState(() => busy = false);
  }
  Future<void> openOfferwall() async {
    if (offerwallPublicKey.isEmpty) { setState(() => message = 'لم يتم ضبط مفتاح Offerwall العام بعد. لا يمكن فتح العروض قبل اعتماد حساب الناشر.'); return; }
    final userId = db.auth.currentUser!.id;
    final uri = Uri.https('offerwall.gg', '/wall/$offerwallPublicKey', {'userId': userId});
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication) && mounted) setState(() => message = 'تعذر فتح صفحة العروض');
  }
  @override Widget build(BuildContext context) {
    if (loading) return const Center(child: Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator()));
    return Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const Text('المحفظة النقدية', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)), const SizedBox(height: 12),
      Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: const Color(0xffeaf0ff), borderRadius: BorderRadius.circular(14)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('الرصيد المتاح للسحب'), Text(money(wallet['available_cents']), style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: Color(0xff1749d1))), Text('المبلغ المحجوز: ${money(wallet['held_cents'])}'), if ((wallet['recovery_cents'] as num? ?? 0) > 0) Text('تسوية استرداد معلقة: ${money(wallet['recovery_cents'])}', style: const TextStyle(color: Colors.deepOrange))])),
      const SizedBox(height: 14), FilledButton.icon(onPressed: openOfferwall, icon: const Icon(Icons.local_offer), label: const Text('عرض المهام والمكافآت')),
      const SizedBox(height: 18), const Text('طلب سحب نقدي من الوكيل', style: TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 8),
      TextField(controller: amount, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'المبلغ بالدولار (الحد الأدنى 5.00)', prefixText: '\$', border: OutlineInputBorder())), const SizedBox(height: 8),
      FilledButton(onPressed: busy ? null : withdraw, child: Text(busy ? 'جارٍ إرسال الطلب...' : 'إرسال طلب السحب إلى الوكيل')),
      if (message.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 10), child: Text(message, style: const TextStyle(color: Colors.blueGrey))),
      const Divider(height: 28), const Text('طلبات السحب السابقة', style: TextStyle(fontWeight: FontWeight.bold)),
      if (requests.isEmpty) const Text('لا توجد طلبات بعد.'),
      for (final r in requests) ListTile(contentPadding: EdgeInsets.zero, title: Text('${money(r['amount_cents'])} • ${statusLabel(r['status'])}'), subtitle: Text('${r['created_at']}')),
      const Divider(height: 28), const Text('آخر حركات المحفظة', style: TextStyle(fontWeight: FontWeight.bold)),
      if (ledger.isEmpty) const Text('لا توجد حركات بعد.'),
      for (final l in ledger) ListTile(contentPadding: EdgeInsets.zero, dense: true, title: Text('${money(l['amount_cents'])} • ${l['entry_type']}'), subtitle: Text('${l['note'] ?? ''}')),
    ])));
  }
}

class AgentCashPanel extends StatefulWidget { const AgentCashPanel({super.key}); @override State<AgentCashPanel> createState() => _AgentCashPanelState(); }
class _AgentCashPanelState extends State<AgentCashPanel> {
  List<dynamic> rows = []; String message = ''; bool loading = true;
  @override void initState() { super.initState(); load(); }
  Future<void> load() async {
    try { rows = await db.from('cash_withdrawal_requests').select('id,amount_cents,status,cash_delivered_at,payout_details,created_at,profiles!cash_withdrawal_requests_user_id_fkey(display_name,public_id)').order('created_at', ascending: false); }
    catch (e) { message = '$e'; }
    if (mounted) setState(() => loading = false);
  }
  Future<void> review(String id, String decision, {Map<String, dynamic> delivery = const {}}) async {
    try { await db.rpc('agent_review_cash_withdrawal', params: {'p_request_id': id, 'p_decision': decision, 'p_note': decision == 'verified' ? 'تم التحقق من هوية صاحب الطلب' : decision == 'cash_delivered' ? 'أكد الوكيل تسليم النقد للمستخدم' : 'رفض الوكيل الطلب', 'p_delivery_details': delivery}); await load(); }
    catch (e) { setState(() => message = '$e'); }
  }
  Future<void> recordCashDelivery(Map<String, dynamic> request) async {
    final currency = TextEditingController(text: '');
    final localAmount = TextEditingController();
    final usd = (request['amount_cents'] as num).toDouble() / 100;
    final result = await showDialog<Map<String, dynamic>>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('تسجيل تسليم النقد'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        Text('قيمة الطلب: ${money(request['amount_cents'])} USD'),
        TextField(controller: currency, textCapitalization: TextCapitalization.characters, decoration: const InputDecoration(labelText: 'رمز العملة المحلية (مثلاً TRY أو EUR)')),
        TextField(controller: localAmount, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'المبلغ النقدي الذي تم تسليمه')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')), FilledButton(onPressed: () {
        final c = currency.text.trim().toUpperCase(); final a = double.tryParse(localAmount.text.replaceAll(',', '.'));
        if (!RegExp(r'^[A-Z]{3}$').hasMatch(c) || a == null || a <= 0) return;
        Navigator.pop(ctx, {'local_currency': c, 'local_amount': a.toStringAsFixed(2), 'usd_amount': usd.toStringAsFixed(2), 'fx_rate': (a / usd).toStringAsFixed(8)});
      }, child: const Text('تأكيد البيانات'))],
    ));
    if (result != null) await review(request['id'], 'cash_delivered', delivery: result);
  }
  @override Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    const Text('طلبات مستخدمي الوكيل', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)), const Text('يمكنك التحقق من هوية العميل وتأكيد تسليم النقد. اعتماد التسوية النهائي للأدمن.'), FilledButton.tonal(onPressed: load, child: const Text('تحديث الطلبات')),
    if (loading) const Center(child: CircularProgressIndicator()), if (rows.isEmpty && !loading) const Text('لا توجد طلبات.'),
    for (final r in rows) Card(child: Padding(padding: const EdgeInsets.all(10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${r['profiles']?['display_name'] ?? 'مستخدم'} • ${r['profiles']?['public_id'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.bold)), Text('${money(r['amount_cents'])} • ${statusLabel(r['status'])}'), Text('رقم الطلب: ${r['id']}'), if (r['status'] == 'pending_agent') Wrap(spacing: 8, children: [OutlinedButton(onPressed: () => review(r['id'], 'verified'), child: const Text('تأكيد الهوية')), TextButton(onPressed: () => review(r['id'], 'rejected'), child: const Text('رفض'))]), if (r['status'] == 'agent_verified' && r['cash_delivered_at'] == null) FilledButton(onPressed: () => recordCashDelivery(Map<String, dynamic>.from(r)), child: const Text('تسجيل تسليم النقد'))]))),
    if (message.isNotEmpty) Text(message),
  ])));
}

class AdminCashPanel extends StatefulWidget { const AdminCashPanel({super.key}); @override State<AdminCashPanel> createState() => _AdminCashPanelState(); }
class _AdminCashPanelState extends State<AdminCashPanel> {
  List<dynamic> users = [], requests = []; String message = ''; bool loading = true;
  @override void initState() { super.initState(); load(); }
  Future<void> load() async {
    try {
      users = await db.from('profiles').select('id,public_id,display_name,role,is_suspended,cash_wallets(available_cents,held_cents,recovery_cents)').order('created_at', ascending: false).limit(200);
      requests = await db.from('cash_withdrawal_requests').select('id,amount_cents,status,cash_delivered_at,payout_details,created_at,profiles!cash_withdrawal_requests_user_id_fkey(display_name,public_id),agents!cash_withdrawal_requests_agent_id_fkey(agent_code,display_name)').order('created_at', ascending: false).limit(200);
    } catch (e) { message = '$e'; }
    if (mounted) setState(() => loading = false);
  }
  Future<void> finalize(String id, String decision) async {
    try { await db.rpc('admin_finalize_cash_withdrawal', params: {'p_request_id': id, 'p_decision': decision, 'p_note': decision == 'paid' ? 'تمت مطابقة تسليم النقد واعتماد التسوية' : 'رفض الأدمن وإرجاع الرصيد'}); await load(); }
    catch (e) { setState(() => message = '$e'); }
  }
  Future<void> suspend(String id, bool value) async {
    try { await db.rpc('admin_set_suspension', params: {'p_user_id': id, 'p_suspended': value}); await load(); }
    catch (e) { setState(() => message = '$e'); }
  }
  Future<void> adjustCash(String id) async {
    final amount = TextEditingController(); final note = TextEditingController();
    final result = await showDialog<Map<String, String>>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('تعديل الرصيد النقدي'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('اكتب مبلغاً موجباً للإضافة أو سالباً للخصم بالدولار.'),
        TextField(controller: amount, keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true), decoration: const InputDecoration(labelText: 'المبلغ بالدولار')),
        TextField(controller: note, decoration: const InputDecoration(labelText: 'سبب التعديل')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(ctx, {'amount': amount.text, 'note': note.text}), child: const Text('تأكيد'))],
    ));
    if (result == null) return;
    final value = double.tryParse(result['amount']!.replaceAll(',', '.'));
    if (value == null || value == 0 || result['note']!.trim().isEmpty) { setState(() => message = 'أدخل مبلغاً صحيحاً وسبب التعديل.'); return; }
    try { await db.rpc('admin_adjust_cash_wallet', params: {'p_user_id': id, 'p_amount_cents': (value * 100).round(), 'p_note': result['note']!.trim()}); await load(); }
    catch (e) { setState(() => message = '$e'); }
  }
  @override Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    const Text('لوحة الأدمن – المحفظة النقدية', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)), FilledButton.tonal(onPressed: load, child: const Text('تحديث البيانات')),
    if (loading) const Center(child: CircularProgressIndicator()), const Divider(), const Text('الحسابات والمحافظ', style: TextStyle(fontWeight: FontWeight.bold)),
    for (final u in users) ListTile(contentPadding: EdgeInsets.zero, title: Text('${u['display_name'] ?? 'بدون اسم'} • ${u['role']}'), subtitle: Text('${u['public_id']} | متاح ${money(walletOf(u['cash_wallets'])?['available_cents'])} | محجوز ${money(walletOf(u['cash_wallets'])?['held_cents'])} | استرداد ${money(walletOf(u['cash_wallets'])?['recovery_cents'])}'), trailing: u['role'] == 'user' ? Wrap(spacing: 0, children: [IconButton(tooltip: 'تعديل المحفظة', icon: const Icon(Icons.account_balance_wallet), onPressed: () => adjustCash(u['id'])), IconButton(tooltip: 'تجميد/تفعيل', icon: Icon(u['is_suspended'] == true ? Icons.lock_open : Icons.block), onPressed: () => suspend(u['id'], u['is_suspended'] != true))]) : null),
    const Divider(), const Text('طلبات الصرف النقدي', style: TextStyle(fontWeight: FontWeight.bold)),
    if (requests.isEmpty && !loading) const Text('لا توجد طلبات.'),
    for (final r in requests) Card(child: Padding(padding: const EdgeInsets.all(10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${r['profiles']?['display_name'] ?? 'مستخدم'} • ${money(r['amount_cents'])}', style: const TextStyle(fontWeight: FontWeight.bold)), Text('الوكيل: ${r['agents']?['display_name'] ?? r['agents']?['agent_code'] ?? '—'}'), Text(statusLabel(r['status'])), if (r['payout_details']?['cash_delivery'] != null) Text('التسليم: ${r['payout_details']['cash_delivery']['local_amount']} ${r['payout_details']['cash_delivery']['local_currency']} • سعر الصرف ${r['payout_details']['cash_delivery']['fx_rate']}'), if (r['status'] == 'agent_verified' && r['cash_delivered_at'] != null) FilledButton(onPressed: () => finalize(r['id'], 'paid'), child: const Text('اعتماد تسليم النقد')), if (r['status'] == 'agent_verified' && r['cash_delivered_at'] == null) TextButton(onPressed: () => finalize(r['id'], 'rejected'), child: const Text('رفض قبل التسليم وإرجاع الرصيد'))]))),
    if (message.isNotEmpty) Text(message),
  ])));
}
