# إعلاناتي — Flutter + Supabase

مشروع أساس لتطبيق Android بثلاثة أدوار: المستخدم والوكيل والأدمن.

## ما يتضمنه الإصدار
- تسجيل دخول وإنشاء حساب وربط كود وكيل.
- رصيد نقاط داخلي منفصل عن المحفظة النقدية.
- محفظة USD بالسنت، دفتر حركات، عروض مكافآت، ومنع تكرار postback.
- طلب سحب نقدي من الوكيل المرتبط.
- الوكيل يتحقق من الهوية ويؤكد تسليم النقد؛ الأدمن يعتمد إقفال التسوية.
- استرداد التحويلات الملغاة من مزود المكافآت وتسويتها من الأرباح القادمة.
- واجهة أدمن لإدارة الحسابات ومراجعة المحافظ وطلبات الصرف.

## مزود المكافآت
المزود المختار مبدئياً هو **Offerwall.GG**. الاختيار مبني على وجود Offerwall مستضاف وAPI وSDKs، واستهداف عروض حسب الدولة والجهاز، وcallback موقّع للتحويلات والعكس. يجب الحصول على موافقة كتابية منهم على نموذج المكافآت النقدية والدول المستهدفة قبل التشغيل. لا يوجد مزود دفع خارجي للمستخدمين: الصرف نقداً من شبكة الوكلاء.

تسوية الناشر: يمكن اختيار وسيلة استلام أرباح الناشر من وسائل Offerwall.GG المتاحة لحسابه؛ SWIFT منشور كخيار للتحويل الدولي، مع التحقق من رسوم البنك وأهلية بلد الناشر. هذا التحويل للناشر وليس للمستخدمين. المستخدمون يستلمون نقداً من الوكلاء.

المصادر الرسمية: https://offerwall.gg/publishers وhttps://offerwall.gg/developers وhttps://offerwall.gg/legal/publisher-terms وhttps://offerwall.gg/payouts

## إعداد Supabase
1. أنشئ مشروع Supabase.
2. شغّل `supabase/schema.sql`.
3. شغّل `supabase/migrations/20261115_cash_wallet.sql`.
4. شغّل `supabase/migrations/20261116_offerwall_gg_cash.sql`.
5. أنشئ أول مستخدم أدمن بعد التحقق من بريده:
   ```sql
   update public.profiles p set role='admin'
   from auth.users u where p.id=u.id and u.email='YOUR_ADMIN_EMAIL';
   ```
6. أنشئ حساب الوكيل أولاً من التطبيق، ثم نفّذ بعد التحقق من بريده:
   ```sql
   insert into public.agents(user_id,agent_code,display_name)
   select id,'AG-1001','وكيل تجريبي' from auth.users where email='AGENT_EMAIL';
   update public.profiles p set role='agent' from auth.users u where p.id=u.id and u.email='AGENT_EMAIL';
   ```
7. انشر callback:
   ```bash
   supabase functions deploy offerwall-gg-postback --no-verify-jwt
   supabase secrets set OFFERWALL_GG_SECRET="YOUR_PLACEMENT_SECRET"
   ```
8. اضبط callback في لوحة Offerwall.GG إلى `https://YOUR_PROJECT_REF.supabase.co/functions/v1/offerwall-gg-postback`، واجعل عملة placement هي USD.
9. لا تشغل المكافآت حتى تختبر callback وتراجع الشروط القانونية لكل بلد.

## تشغيل Flutter وبناء APK
لأن ملفات Android platform لا تُضمّن في حزمة المصدر، أنشئها مرة واحدة من مجلد المشروع باستخدام Flutter SDK:
```bash
flutter create . --platforms android
flutter pub get
flutter run --dart-define=SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co --dart-define=SUPABASE_ANON_KEY=YOUR_PUBLIC_KEY --dart-define=OFFERWALL_PUBLIC_KEY=YOUR_OFFERWALL_PUBLIC_KEY
```

```bash
flutter build apk --release --dart-define=SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co --dart-define=SUPABASE_ANON_KEY=YOUR_PUBLIC_KEY --dart-define=OFFERWALL_PUBLIC_KEY=YOUR_OFFERWALL_PUBLIC_KEY
```

لا تضع `SUPABASE_SERVICE_ROLE_KEY` أو سر Offerwall داخل تطبيق Flutter مطلقاً.

## حالة الإصدار
هذه ملفات مصدر محدثة وليست APK مبنياً. يلزم تثبيت Flutter وAndroid SDK، إعداد Supabase وحساب Offerwall، تشغيل migrations، نشر Edge Function، ثم اختبار التطبيق قبل إصدار APK. راجع `docs/offerwall_integration.md` و`docs/acceptance_checklist.md`.
